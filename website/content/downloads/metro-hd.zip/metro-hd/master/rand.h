#ifndef RAND_H
#define RAND_H

int random_below(int RANGE);
int really_random_below(int RANGE);

#endif
